function w = boxcar(n)

% BOXCAR returns a boxcar taper
%
% Use as
%   w = boxcar(n)

w = ones(n,1);

