function a = iscomplex(X)
a = ~isreal(X);
end